# Guia de Publicação da Landing Page "Desperta!" no Instagram

## Resumo do Projeto

Sua landing page "Desperta!" foi criada com sucesso! A página está totalmente responsiva, otimizada para dispositivos móveis e alinhada com a identidade visual da sua marca.

## Características da Landing Page

### Design e Estilo Visual
- **Paleta de cores:** Utiliza as cores da sua marca (#8b0000, #4e1e34, #f4a988, #b48508)
- **Tipografia:** Playfair Display para títulos e Montserrat para textos
- **Arquétipos:** Incorpora elementos da Maga, Amante e Rebelde
- **Responsividade:** Totalmente otimizada para mobile (essencial para Instagram)

### Conteúdo Estratégico
- **Título impactante:** "DESPERTA!" em destaque
- **Mensagem central:** "Porque confiança mora no corpo, não na mente"
- **Informações claras:** Datas, locais e preços bem visíveis
- **Urgência:** "Vagas limitadas!" para incentivar ação imediata
- **CTAs duplos:** Formulário de inscrição + Instagram

### Seções da Landing Page
1. **Hero Section:** Título, subtítulo e informações do evento
2. **Mergulho Transformador:** Apresentação da vivência
3. **Métodos:** Terapia do movimento, cristais, olhar sistêmico, 5 elementos
4. **Benefícios:** Lista de transformações esperadas
5. **Público-alvo:** Para quem é a vivência
6. **Chamada para ação:** Botões de inscrição
7. **Rodapé:** Informações de contato

## Como Publicar no Instagram

### Opção 1: Hospedagem Gratuita (Recomendada)

1. **Netlify (Gratuito e Fácil):**
   - Acesse: https://www.netlify.com
   - Crie uma conta gratuita
   - Arraste o arquivo `desperta-landing-page.zip` para a área de deploy
   - Copie o link gerado (ex: https://amazing-name-123456.netlify.app)

2. **GitHub Pages (Gratuito):**
   - Crie uma conta no GitHub
   - Crie um novo repositório público
   - Faça upload dos arquivos da landing page
   - Ative o GitHub Pages nas configurações
   - Use o link gerado

### Opção 2: Hospedagem Paga

1. **Hostinger, GoDaddy, ou similar:**
   - Compre um domínio personalizado (ex: desperta.com)
   - Faça upload dos arquivos via FTP ou painel de controle
   - Configure o domínio

### Configuração no Instagram

1. **Link na Bio:**
   - Vá para "Editar perfil" no Instagram
   - No campo "Website", cole o link da sua landing page
   - Salve as alterações

2. **Stories com Link:**
   - Se você tem mais de 10k seguidores ou conta verificada
   - Use o sticker "Link" nos Stories
   - Cole o link da landing page

3. **Posts com Call-to-Action:**
   - Publique as imagens da vivência que você já criou
   - Na legenda, inclua: "Link na bio para inscrições"
   - Use hashtags relevantes: #desperta #poderPessoal #autoconfiança #consciênciacorporal

## Texto Sugerido para Posts no Instagram

### Post Principal:
```
🔥 DESPERTA! 🔥

A tua autoconfiança não está na mente, está no corpo!

Na tua postura.
No teu olhar.
Na forma como ocupas o espaço.

✨ 17 de junho - Porto
✨ 18 de junho - Lisboa

Vivência de 1h30 para despertar o poder que já existe em ti.

€35 até 13/06 | €45 a partir de 13/06
⚡ VAGAS LIMITADAS! ⚡

Link na bio para inscrições 👆

#desperta #poderPessoal #autoconfiança #consciênciacorporal #terapiadoMovimento #cristais #transformação #mulheresempoderadas #porto #lisboa
```

### Stories Sugeridos:
- "Swipe up para te inscreveres" (se tiver link nos Stories)
- "Link na bio 👆"
- Countdown para o evento
- Depoimentos (se houver)

## Monitoramento e Otimização

### Métricas para Acompanhar:
- Cliques no link da bio
- Tempo de permanência na landing page
- Taxa de conversão (inscrições)
- Origem do tráfego

### Ferramentas Recomendadas:
- Google Analytics (gratuito)
- Bitly para encurtar links e ver estatísticas
- Instagram Insights para métricas do perfil

## Dicas Importantes

1. **Teste o link:** Sempre teste o link antes de publicar
2. **Mobile first:** A maioria dos usuários do Instagram usa mobile
3. **Velocidade:** A página foi otimizada para carregar rapidamente
4. **Backup:** Mantenha sempre uma cópia dos arquivos
5. **Atualizações:** Você pode facilmente atualizar o conteúdo editando o arquivo HTML

## Próximos Passos

1. Escolha uma plataforma de hospedagem
2. Faça upload da landing page
3. Teste o link em diferentes dispositivos
4. Atualize o link na bio do Instagram
5. Publique os posts de divulgação
6. Monitore as métricas e ajuste conforme necessário

## Suporte Técnico

Se precisar de ajuda com:
- Hospedagem da página
- Configuração de domínio personalizado
- Integração com formulários de inscrição
- Análise de métricas

Não hesite em entrar em contato!

---

**Sua landing page está pronta para converter visitantes em participantes da vivência Desperta! 🚀**

